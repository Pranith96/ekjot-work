package com.example1;

public class Subtraction {

	public void sub() {
		Summation sm = new Summation();
		sm.hi();
		sm.sum();
	}
}

package com.example1;

import com.example.Addition;

public class Summation extends Addition {
	
	public void sum() {
		Addition ad = new Addition();
		ad.hi();
	}

}

package com.example;

public class Addition {

	public void hi() {
		System.out.println("hi");
		hello();
	}

	private void hello() {
		System.out.println("hello");
	}

	protected void welcome() {
		System.out.println("welcome");
	}

	void print() {
		System.out.println("print");
	}
}

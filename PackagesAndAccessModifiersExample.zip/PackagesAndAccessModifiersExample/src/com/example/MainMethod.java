package com.example;

import com.example1.Summation;

public class MainMethod {

	public static void main(String[] args) {
		Calculator cl = new Calculator();
		cl.calc();
		
		Summation sm = new Summation();
		sm.sum();
	}
}
package com.example;

public class Calculator {

	public void calc() {
		Addition ad = new Addition();
		ad.hi();
		ad.welcome();
		ad.print();
	}
}

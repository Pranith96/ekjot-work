
public class MainMethod {
	
	public static void main(String[] args) {
			BulletBike bike = new BulletBike();
			bike.breaks();
			bike.engine();
			bike.hi();
			bike.mirror();
			bike.petrolTank();
			bike.tires();
			bike.seat();
	}

}

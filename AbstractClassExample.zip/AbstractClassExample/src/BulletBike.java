
public class BulletBike extends MotorBike{

	public void mirror() {
		System.out.println("mirror");
	}
	
	public void seat() {
		System.out.println("seat");
	}
}

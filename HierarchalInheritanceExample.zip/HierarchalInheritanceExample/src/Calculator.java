
public class Calculator {

	public void printNumbers(int n) {
		for (int i = 0; i <= n; i++) {
			System.out.print(i + " ");
		}
	}
}


public class Addition extends Calculator {

	public void add(int a, int b) {
		System.out.println(a + b);
	}
}

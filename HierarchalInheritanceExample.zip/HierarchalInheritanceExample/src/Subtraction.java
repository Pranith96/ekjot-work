
public class Subtraction extends Calculator {

	public void sub(int a, int b) {
		System.out.println(a - b);
	}
}

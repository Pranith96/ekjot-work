
@FunctionalInterface
public interface Summation {

	public void add(int a, int b);
	
}

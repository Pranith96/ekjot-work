
@FunctionalInterface
public interface Calculation {

	public int sum(int a, int b);
	
}

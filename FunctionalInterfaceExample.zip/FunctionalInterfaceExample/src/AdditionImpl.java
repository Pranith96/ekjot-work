
public class AdditionImpl implements Addition{

	public void hello() {
		System.out.println("hi");
	}
}

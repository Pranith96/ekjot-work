
@FunctionalInterface
public interface Addition {

	public void hello();
	
}

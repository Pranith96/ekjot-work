
public interface Bike {

	public void engine();

	public void mirror();

	public void seat();

	public void tire();

	public void breaks();

}

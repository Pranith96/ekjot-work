
public interface Bike2 {

	public void engine();

	public void mirror();

	public void seat();

	public void tire();

	public void breaks();

}

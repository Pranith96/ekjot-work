
public class Colors {

	public void whiteColor(String data) {
		System.out.println(data);
	}

	public void redColor(String data, String data2) {
		System.out.println(data + " " + data2);
	}

	public void blackColor(String data, String data2, String data3) {
		System.out.println(data + " " + data2 + " " + data3);
	}

	public static void hi() {
		System.out.println("in parent method");
	}
}

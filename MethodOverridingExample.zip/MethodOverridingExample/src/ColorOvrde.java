
public class ColorOvrde extends Colors {

	public void whiteColor(String data) {
		System.out.println("result" + data);
	}

	public void redColor(String data, String data2) {
		System.out.println("result" + data + " " + data2);
	}

	public void blackColor(String data, String data2, String data3) {
		System.out.println("result" + data + " " + data2 + " " + data3);
	}

	public static void hi() {
		System.out.println("in child method");
	}
}

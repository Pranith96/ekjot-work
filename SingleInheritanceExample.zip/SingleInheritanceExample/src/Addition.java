
public class Addition {

	public void hi() {
		System.out.println("Inside hi method");
	}

	public void add(int a, int b) {
		int c = a + b;
		System.out.println("result= " + c);
	}
}

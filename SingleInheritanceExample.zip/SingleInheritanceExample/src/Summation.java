
public class Summation extends Addition {

	public String welcome(String message) {
		String response = "Hi Hello Welcome " + message;
		return response;
	}
}

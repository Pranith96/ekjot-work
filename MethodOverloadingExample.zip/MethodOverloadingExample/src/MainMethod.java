
public class MainMethod {

	public static void main(String[] args) {
		Addition ad = new Addition();
		ad.add(5, 5);
		ad.add(5, 5, 5);
		ad.add(5, 5000l, 5);
	}
}
